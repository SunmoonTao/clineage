Please see `contribution-guide.org <http://www.contribution-guide.org/>`_ for
details on what we expect from contributors. Thanks!
